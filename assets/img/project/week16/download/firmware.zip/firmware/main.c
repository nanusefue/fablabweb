#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/eeprom.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <stdlib.h>
#include "usbdrv.h"
#include "oddebug.h"

/* ------------------------------------------------------------------------- */
static uchar    reportBuffer[2];    /* buffer for HID reports */
static uchar    idleRate;           /* in 4 ms units */
static uchar    reportCount=0;		/* current report */
static uchar    keypad[7]={0x00,0x4F,0x50,0x51,0x52,0x2C,0x28};

/* ------------------------------------------------------------------------- */

PROGMEM const char usbHidReportDescriptor[USB_CFG_HID_REPORT_DESCRIPTOR_LENGTH] = { /* USB report descriptor */
    0x05, 0x01,                    // USAGE_PAGE (Generic Desktop)
    0x09, 0x06,                    // USAGE (Keyboard)
    0xa1, 0x01,                    // COLLECTION (Application)
    0x05, 0x07,                    //   USAGE_PAGE (Keyboard)
    0x19, 0xe0,                    //   USAGE_MINIMUM (Keyboard LeftControl)
    0x29, 0xe7,                    //   USAGE_MAXIMUM (Keyboard Right GUI)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x25, 0x01,                    //   LOGICAL_MAXIMUM (1)
    0x75, 0x01,                    //   REPORT_SIZE (1)
    0x95, 0x08,                    //   REPORT_COUNT (8)
    0x81, 0x02,                    //   INPUT (Data,Var,Abs)
    0x95, 0x01,                    //   REPORT_COUNT (1)
    0x75, 0x08,                    //   REPORT_SIZE (8)
    0x25, 0x65,                    //   LOGICAL_MAXIMUM (101)
    0x19, 0x00,                    //   USAGE_MINIMUM (Reserved (no event indicated))
    0x29, 0x65,                    //   USAGE_MAXIMUM (Keyboard Application)
    0x81, 0x00,                    //   INPUT (Data,Ary,Abs)
    0xc0                           // END_COLLECTION
};
/*
    0x4F    Keyboard RightArrow
    0x50    Keyboard LeftArrow
    0x51    Keyboard DownArrow
    0x52    Keyboard UpArrow
    0x28    Keypad ENTER
    0x2C    Keyboard Spacebar

*/ 


static void buildReport(uchar key)
{

    if(key!=0){
        reportBuffer[0] = 0;    /* no modifiers */
        reportBuffer[1] = keypad[key];
    }else
    {
        reportBuffer[1] =0x00;
    }

}

static uchar keyPress(void) {
	
    reportCount++;
    uchar  i, mask, x;
    x=PINA;
    
    mask = 1 << 1;
    for (i = 0; i < 7; ++i)
    {
    
        if((x & mask) == 0)
                    return i+1;  
                           
        mask <<= 1 ;
    }
    
    return 0;   

}

/* -------------------------------------------------------------------------------- */
/* ------------------------ interface to USB driver ------------------------ */
/* -------------------------------------------------------------------------------- */

uchar	usbFunctionSetup(uchar data[8])
{
usbRequest_t    *rq = (void *)data;

    usbMsgPtr = reportBuffer;
    if((rq->bmRequestType & USBRQ_TYPE_MASK) == USBRQ_TYPE_CLASS){    /* class request type */
        if(rq->bRequest == USBRQ_HID_GET_REPORT){  /* wValue: ReportType (highbyte), ReportID (lowbyte) */
            buildReport(keyPress());
            return sizeof(reportBuffer);
        }else if(rq->bRequest == USBRQ_HID_GET_IDLE){
            usbMsgPtr = &idleRate;
            return 1;
        }else if(rq->bRequest == USBRQ_HID_SET_IDLE){
            idleRate = rq->wValue.bytes[1];
        }
    }else{
        /* no vendor specific requests implemented */
    }
	return 0;
}


/* ------------------------------------------------------------------------- */
/* --------------------------------- main ---------------------------------- */
/* ------------------------------------------------------------------------- */

int main(void)
{

  // PORTA=0x7E; digital 

  PORTA=0x00; //banana
 
    uchar   i,key,lastKey,keyDidChange=0,newkeyDidChange=0;
    usbInit();
    usbDeviceDisconnect();  /* enforce re-enumeration, do this while interrupts are disabled! */

    while(--i){             /* fake USB disconnect for > 250 ms */
        wdt_reset();
    }
    usbDeviceConnect();

    wdt_enable(WDTO_1S);

    sei();

    for(;;){    /* main event loop */
        wdt_reset();
        usbPoll();

        key= keyPress();
         if(lastKey != key){
            lastKey = key;
            keyDidChange = 1;

        }

    	if(keyDidChange && usbInterruptIsReady()){ /* we can send another key */
            keyDidChange = 0;
        	buildReport(lastKey);
           	usbSetInterrupt(reportBuffer, sizeof(reportBuffer));
        }
   }
   	return 0;
}



